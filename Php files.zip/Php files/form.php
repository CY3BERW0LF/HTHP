<!DOCTYPE html>

<!-- form.html -->
<!-- HTML form for gathering user input. -->
<html>
	<head>
		<meta charset = "utf-8">
		<title>Sample form</title>
		<style type = "text/css">
			label { width: 5em; float: left; }
		</style>
	</head>
	<body>
		<h1>Registration Form</h1>
		<p>Please fill in all fields and click Register.</p>
		<!-- post form data to form.php -->
		<form method = "post" action = "ClassForm2.php">
		<h2>User Information</h2>

		<!-- create four text boxes for user input -->
		<div><label>First name:</label>
			<input type = "text" name = "fname"></div>
		<div><label>Phone:</label>
			<input type = "text" name = "phone"
				placeholder = "(555) 555-5555"></div>
		<h2>Publications</h2>
		<p>Which book would you like information about?</p>

		<!-- create drop-down list containing book names -->
		<select name = "book">
			<option>C++ How to program</option>
			<option>Java How to Program</option>
		</select>
		<!-- create a submit button -->
		<p><input type = "submit" name = "submit" value = "Register"></p>
		</form>
	</body>
</html>