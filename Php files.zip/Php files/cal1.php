<!DOCTYPE html>
<html>
	<head>
		<meta charset = "utf-8">
		<title>Calculator</title>
	<head>
	
	<body>
	
	<form>
		<input type="text" name="num1" placeholder="Number 1">
		<input type="text" name="num2" placeholder="Number 2">
		<select name="operator">
			<option> Add</option>
			<option> Multiply</option>
			<option> Subtraction</option>
			<option> Division</option>
			
			</select>
			<br>
			<button type="submit" name="submit" value="submit"> Calculate</button>
		</form>
		<p> The answer is: </p>
		<?PHP
			if (isset($_GET['submit'])){
				$result1 = $_GET['num1'];
				$result2 = $_GET['num2'];
				$operator = $_GET['operator'];
				switch ($operator){
					case "Add":
					echo $result1 + $result2;
					break;
					case "Multiply":
					echo $result1 * $result2;
					break;
					case "Subtraction":
					echo $result1 - $result2;
					break;
					case "Division":
					echo $result1 / $result2;
					break;
				}
		    }
		?>
	</body>
</html>