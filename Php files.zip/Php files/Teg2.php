<!DOCTYPE html>
<html>
	<head>
		<meta charset = "utf-8">
		<title>Calculator</title>
	<head>
	
	<body>
	</form>
	<p> Which shape would you like to find the area of? </p>
	<form>
	<div>
	<select name="operator">
			<option> Rectangle</option> 
			<option> Square</option>
			<option> Triangle</option>
			<option> Trapezoid</option>
			<option> Circle</option>
			</select>
		<input type="text" name="num1" placeholder="Base">
		<input type="text" name="num2" placeholder="Height">
	</div>
	<div>
	<select name="operator">
		<option value="Rectangle">Rectangle</option> 
			<option value="Square">Square</option>
			<option value="Triangle">Triangle</option>
			<option> Trapezoid</option>
			<option> Circle</option>
			</select>
		<input type="text" name="num1" placeholder="Base">
		<input type="text" name="num2" placeholder="Base 2">
		<input type="text" name="num3" placeholder="Height">
	</div>
		
			<button type="submit" name="submit" value="submit"> Calculate</button>
		</form>
		<p> The answer is: </p>
		<?PHP
			if (isset($_GET['submit'])){
				$result1 = $_GET['num1'];
				$result2 = $_GET['num2'];
				$operator = $_GET['operator'];
				switch ($operator){
					case "Rectangle":
					echo $result1 * $result2;
					break;
					case "Square":
					echo ($result1 * $result1);
					break;
					case "Triangle":
					echo ($result1 * $result2)/2;
					break;
					case "Trapezoid":
					echo $result1 - $result2;
					break;
					case "Circle":
					echo $result1/$result2;
					break;
					
				}
		    }
			
		?>
	</body>
</html>